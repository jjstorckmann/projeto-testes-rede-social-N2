# Pasta mocks

Reservada para possíveis dados falsos.
Atualmente não utilizada, pois os testes unitários usam stubs via Sinon.
